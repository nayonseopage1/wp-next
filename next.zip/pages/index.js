import About from '../src/component/About';
import Layout from '../src/component/Layout';
import getNavData from '../src/inc/getNavData';
import homeData from '../src/inc/homeData';

const Home = ({headerMenu,homeOutput}) => {
  
  const hmOutput = homeOutput.data.HomePage.aboutSection;
  return (
      <Layout headerMenu={headerMenu}>
          <div>
              <h1>home page 3</h1>
              <About hmOutput={hmOutput}></About>
              
          </div>
      </Layout>
  );
};

export async function getStaticProps(context) {
    return {
      props: {
        headerMenu : await getNavData(),
        homeOutput : await homeData()
      }
    }
  }

export default Home;

