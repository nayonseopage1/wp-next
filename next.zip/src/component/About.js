import React from 'react';

const About = ({hmOutput}) => {
    return (
        <div>
            <h1>{hmOutput.textTitle}</h1>
            <p>{hmOutput.demoTextarea}</p>
        </div>
    );
};

export default About;