import {
    gql
  } from "@apollo/client";
import { client } from "./apploClient";


  const homeData = async() => {
        const HomePageData = await client.query({
        query: gql`
            query HmeData {
                HomePage : pageBy (uri: "https://seia.internaltest.website/home/") {
                aboutSection {
                    textTitle
                    demoTextarea
                }
                }
            }        
        `
        })
        return HomePageData;
  }
  
  export default homeData;